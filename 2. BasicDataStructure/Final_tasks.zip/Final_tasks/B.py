'''
ID решения: 52233244

--- ПРИНЦИП РАБОТЫ ---
    Класс Stack представляет собой реализацию стека на списке (пайтоновский list,
    а не двусвязный список). При создании стека создается пустой список, где будут хранится
    добавляемые элументы. Стек содержит номер индекса последнего элемента в списке
    (атрибут tail), с помощью которого вставка и извлечение элементов по принципу
    FIFO осуществляется за О(n)

--- ВРЕМЕННАЯ СЛОЖНОСТЬ ---
    Вставка и извлечение элемента происходит за О(1), так как у нас хранится индекс конца
    списка

--- ПРОСТРАНСТВЕННАЯ СЛОЖНОСТЬ ---
    Пространственная сложность алгоритма составляет О(n), так как элементы (причем не все,
    только числа, математические операции выполняются сразу и нигде не сохраняются) хранятся в
    списке без каких-либо дополнительных метаданных
'''


from typing import List, Tuple


OPERATIONS = '+', '-', '*', '/'


class Stack:
    def __init__(self):
        self.nums = []
        self.tail = -1

    def push(self, value: int) -> None:
        self.nums.append(value)
        self.tail += 1

    def get_nums(self) -> Tuple[int, int]:
        b = self.nums.pop()
        a = self.nums.pop()
        self.tail -= 2
        return a, b

    def get_answer(self) -> int:
        return self.nums[0]


def add(stack: Stack) -> None:
    a, b = stack.get_nums()
    stack.push(a + b)


def subtract(stack: Stack) -> None:
    a, b = stack.get_nums()
    stack.push(a - b)


def multiply(stack: Stack) -> None:
    a, b = stack.get_nums()
    stack.push(a * b)


def division(stack: Stack) -> None:
    a, b = stack.get_nums()
    stack.push(a // b)


operations = {
    '+': add,
    '-': subtract,
    '*': multiply,
    '/': division
}


def solve(exp: List[str]) -> int:
    stack = Stack()
    for elem in exp:
        if elem in OPERATIONS:
            operation = operations.get(elem)
            operation(stack)
        else:
            stack.push(int(elem))
    return stack.get_answer()


if __name__ == '__main__':
    expression = input().strip().split()
    print(solve(expression))