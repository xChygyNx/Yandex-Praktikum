'''
ID решения: 52232793

--- ПРИНЦИП РАБОТЫ ---
    Класс Deque представляет собой реализацию двусторонней очереди на списке (пайтоновский list,
    а не двусвязный список). При создании очереди указывается ее максимальный размер, по достижении
    которого попытка добавления нового элемента будет приводить к выдаче сообщения об ошибке.
    Также сообщение об ошибке будет выдаваться при попытке извлечения элемента из пустой
    очереди.

--- ВРЕМЕННАЯ СЛОЖНОСТЬ ---
    Вставка и извлечение элемента из конца очереди происходит за О(1), вставка и извлечение
    из начала очереди происходит за О(n), так как при вставке элемента в начало пайтоновского
    list приводит к сдвигу всех элементов, находящихся после места вставки

--- ПРОСТРАНСТВЕННАЯ СЛОЖНОСТЬ ---
    Пространственная сложность алгоритма составляет О(n), так как элементы хранятся в
    списке без каких-либо дополнительных метаданных
'''


class Deque:
    def __init__(self, max_size: int):
        self.store = []
        self.max_size = max_size
        self.tail = 0

    def push_front(self, value: int) -> None:
        if self.tail == self.max_size:
            print('error')
        else:
            self.tail += 1
            self.store.insert(0, value)

    def push_back(self, value: int) -> None:
        if self.tail == self.max_size:
            print('error')
        else:
            self.tail += 1
            self.store.append(value)

    def pop_front(self) -> None:
        if self.tail == 0:
            print('error')
        else:
            self.tail -= 1
            value = self.store.pop(0)
            print(value)

    def pop_back(self) -> None:
        if self.tail == 0:
            print('error')
        else:
            self.tail -= 1
            value = self.store.pop(self.tail)
            print(value)


def create_deque() -> Deque:
    max_size = int(input())
    return Deque(max_size)


def execute_cmd(n_cmd: int, deq: Deque) -> None:
    for _ in range(n_cmd):
        cmd = input().strip()
        if cmd.startswith('push'):
            cmd, value = cmd.split()
            value = int(value)
        if cmd == 'push_front':
            deq.push_front(value)
        elif cmd == 'push_back':
            deq.push_back(value)
        elif cmd == 'pop_back':
            deq.pop_back()
        elif cmd == 'pop_front':
            deq.pop_front()


if __name__ == '__main__':
    n_cmd = int(input())
    deq = create_deque()
    execute_cmd(n_cmd, deq)
